# Changelog

All notable changes to this project are documented here.

The format is based on Keep a Changelog and this project follows Semantic Versioning.

## [Unreleased]

## [0.2.0] - 2026-09-07

### Added
- Added a GPT-5.6 Sol/high reasoning lane between Sol/medium and GPT-6 Astra.
- Added progressive-disclosure runtime references for routing/escalation, delegation/context, and verification.
- Added `agents/openai.yaml` Skill metadata and an embedded Skill license.
- Added an official OpenAI documentation audit and a real-workload paired benchmark template and summarizer.
- Added content-hashed installation manifests, source/install validation, rollback-aware updates, and modification-safe uninstall behavior.
- Added regression cases for authority gaps, context-transfer cost, coordination cost, and qualified capability escalation.

### Changed
- Reduced the always-loaded `SKILL.md` from roughly 13 KB to under 7 KB and narrowed implicit invocation boundaries.
- Replaced technology-keyword Astra triggers with a general gate based on reducible uncertainty, consequence, reversibility, novelty, evidence conflict, cheap falsification, and qualified lower-lane failure.
- Added failure triage before model escalation: specification/authority, environment, verifiability, implementation, and capability failures now have distinct responses.
- Set all supplied agent presets to low output verbosity; Luna, Terra, and normal Sol use medium reasoning by default.
- Made current-agent execution and direct tool concurrency precede subagent creation; capped default child guidance at two.
- Clarified that `xhigh`, `max`, Ultra, and Fast mode are never automatic.
- Expanded the English and Chinese READMEs with complete install, update, validation, rollback, and uninstall instructions.

### Security
- The uninstaller now refuses to delete locally modified managed files or paths not proven by a valid install manifest unless the user explicitly supplies `--force`.
- Project-scoped backups are stored outside the target repository by default.

## [0.1.0] - 2026-09-07

### Added
- Initial `codex-efficiency-router` Skill.
- GPT-6 Astra escalation lane using `gpt-6-astra`.
- GPT-5.6 Sol, Terra, and Luna execution presets.
- Quality-first routing policy with mandatory de-escalation after decisions freeze.
- Token/latency guardrails: one-agent default, direct tool concurrency, bounded subagents, compact handoffs.
- User- and repository-scoped cross-platform installers.
- Doctor, uninstall, routing regression cases, CI, security, contributing, and bilingual documentation.
