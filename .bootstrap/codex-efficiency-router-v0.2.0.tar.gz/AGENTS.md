# Repository instructions for coding agents

This repository defines a routing policy whose primary invariant is: **do not claim efficiency by accepting lower verified quality**.

When changing the project:

- keep runtime dependencies at zero unless a measured requirement justifies one;
- do not add a separate LLM routing call to the default path;
- preserve current-agent/tool-first execution, compact handoffs, bounded parallelism, and mandatory high-model de-escalation;
- keep the runtime `SKILL.md` under the enforced context budget and move rare detail into references;
- preserve the installer's non-destructive behavior and its rule of not modifying `config.toml`;
- preserve manifest/path/hash checks and safe rollback/uninstall semantics;
- verify current OpenAI model identifiers, effort levels, discovery paths, and behavioral claims against official documentation before changing compatibility claims;
- add or update `tests/cases.json` whenever routing behavior changes;
- update both READMEs and `docs/OFFICIAL-AUDIT.md` when installation or externally visible behavior changes;
- do not fabricate Token, latency, or quality improvements; use the paired benchmark protocol and disclose inconclusive results;
- avoid unrelated repository-wide formatting changes.

Before completion, run:

```bash
python -m compileall -q scripts tests
python -m unittest discover -s tests -v
python scripts/doctor.py --source-tree .
```

On macOS/Linux also run:

```bash
sh -n install.sh uninstall.sh
```
